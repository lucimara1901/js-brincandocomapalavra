function setup() {
  createCanvas(500, 500);
  background("blue");
}

function draw() {
    
  stroke("white");
  fill("rgb(165,0,255)");
  
 // console.log(mouseIsPressed);
  
  if (mouseIsPressed){
  rect(mouseX,mouseY,60,60);
  }
}